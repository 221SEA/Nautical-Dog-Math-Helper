import SwiftUI

struct AppView: View {
    @State private var selectedTab = 0
    @State private var previousTab = 0
    @StateObject private var router = MoreRouter()
    @StateObject private var nightMode = NightMode()

    var body: some View {
        TabView(selection: $selectedTab) {
            HomeView(selectedTab: $selectedTab)
                .environmentObject(router)
                .environmentObject(nightMode)
                .tabItem {
                    Label("Home", systemImage: "house")
                }
                .tag(0)

            ROTView()
                .environmentObject(nightMode)
                .tabItem {
                    Label("ROT", systemImage: "arrow.clockwise.circle")
                }
                .tag(1)

            TurnView()
                .environmentObject(nightMode)
                .tabItem {
                    Label("Turn", systemImage: "arrow.triangle.turn.up.right.circle")
                }
                .tag(2)

            RPMView()
                .environmentObject(nightMode)
                .tabItem {
                    Label("RPM", systemImage: "gauge")
                }
                .tag(3)

            MoreView()
                .environmentObject(router)
                .environmentObject(nightMode)
                .tabItem {
                    Label("More", systemImage: "ellipsis.circle")
                }
                .tag(4)
        }
        .accentColor(Color("AccentColor"))
        .onChange(of: selectedTab) { newTab in
            if newTab == 4 {
                // Always reset More menu when landing on the tab
                DispatchQueue.main.async {
                    router.reset()
                }
            }
            previousTab = newTab
        }
        .preferredColorScheme(nightMode.isEnabled ? .dark : .light)
    }
}

struct AppView_Previews: PreviewProvider {
    static var previews: some View {
        AppView()
    }
}
