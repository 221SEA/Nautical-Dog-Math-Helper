import SwiftUI

struct ConvertView: View {
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var systemColorScheme

    @State private var inputValue: String = ""
    @State private var fromUnit: String = "Feet"
    @State private var toUnit: String = "Meters"

    let units = ["Feet", "Meters", "Fathoms", "Shackles", "Statute Miles", "Nautical Miles"]
    let conversionFactors: [String: Double] = [
        "Feet": 0.3048,
        "Meters": 1.0,
        "Fathoms": 1.8288,
        "Shackles": 27.432,
        "Statute Miles": 1609.34,
        "Nautical Miles": 1852.0
    ]

    var convertedValue: Double {
        guard let input = Double(inputValue),
              let fromFactor = conversionFactors[fromUnit],
              let toFactor = conversionFactors[toUnit] else {
            return 0.0
        }
        return (input * fromFactor) / toFactor
    }

    var isDark: Bool {
        nightMode.isEnabled || systemColorScheme == .dark
    }

    var body: some View {
        ZStack {
            (isDark ? Color.black : Color("TileBackground"))
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(spacing: 20) {
                    Text("Unit Converter")
                        .font(.custom("Avenir", size: 34))
                        .bold()
                        .padding(.top)
                        .foregroundColor(isDark ? .green : .black)

                    InputField(label: "Value to Convert", placeholder: "Enter Value", text: $inputValue)

                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Text("From:")
                                .foregroundColor(isDark ? .green : .black)

                            Picker("From Unit", selection: $fromUnit) {
                                ForEach(units, id: \.self) { unit in
                                    Text(unit)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }

                        HStack {
                            Text("To:")
                                .foregroundColor(isDark ? .green : .black)

                            Picker("To Unit", selection: $toUnit) {
                                ForEach(units, id: \.self) { unit in
                                    Text(unit)
                                }
                            }
                            .pickerStyle(MenuPickerStyle())
                        }
                    }

                    Text("Converted Value: \(convertedValue, specifier: "%.4f")")
                        .font(.headline)
                        .padding()
                        .foregroundColor(isDark ? .green : .black)

                    Spacer()
                }
                .padding()
            }
        }
        .dismissKeyboardOnTap()
    }
}

struct ConvertView_Previews: PreviewProvider {
    static var previews: some View {
        ConvertView()
            .environmentObject(NightMode())
            .preferredColorScheme(.dark)
    }
}
