import SwiftUI

struct ROTView: View {
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var systemColorScheme

    @State private var speed: String = ""
    @State private var radius: String = ""
    @State private var rot: String = ""
    @State private var selectedCalculation: String = "ROT"
    @State private var result: String = ""

    var isDark: Bool {
        nightMode.isEnabled || systemColorScheme == .dark
    }

    var body: some View {
        ZStack {
            (isDark ? Color.black : Color("TileBackground"))
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Rate of Turn Calculator")
                        .font(.custom("Avenir", size: 34))
                        .bold()
                        .padding()
                        .foregroundColor(isDark ? .green : .black)

                    Picker("Calculation", selection: $selectedCalculation) {
                        Text("ROT").tag("ROT")
                        Text("Radius").tag("Radius")
                        Text("Speed").tag("Speed")
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .tint(isDark ? .green : .black)
                    .padding()

                    VStack(spacing: 20) {
                        if selectedCalculation == "ROT" {
                            InputField(label: "Speed (knots)", placeholder: "Enter speed", text: $speed)
                            InputField(label: "Radius (nm)", placeholder: "Enter radius", text: $radius)
                        } else if selectedCalculation == "Radius" {
                            InputField(label: "Speed (knots)", placeholder: "Enter speed", text: $speed)
                            InputField(label: "ROT (deg/min)", placeholder: "Enter ROT", text: $rot)
                        } else if selectedCalculation == "Speed" {
                            InputField(label: "ROT (deg/min)", placeholder: "Enter ROT", text: $rot)
                            InputField(label: "Radius (nm)", placeholder: "Enter radius", text: $radius)
                        }
                    }

                    Button("Calculate", action: calculate)
                        .buttonStyle(FilledButtonStyle())
                        .padding(.horizontal)

                    if !result.isEmpty {
                        Text("Result: \(result)")
                            .font(.headline)
                            .foregroundColor(isDark ? .green : .black)
                            .padding()
                    }

                    Spacer()
                }
                .padding()
            }
        }
        .dismissKeyboardOnTap()
    }

    private func calculate() {
        if selectedCalculation == "ROT" {
            guard let speed = Double(speed), let radius = Double(radius) else {
                result = "Invalid input"
                return
            }
            let rot = (0.955 * speed) / radius
            result = String(format: "%.2f deg/min", rot)

        } else if selectedCalculation == "Radius" {
            guard let speed = Double(speed), let rot = Double(rot) else {
                result = "Invalid input"
                return
            }
            let radius = (0.955 * speed) / rot
            result = String(format: "%.2f nm", radius)

        } else if selectedCalculation == "Speed" {
            guard let rot = Double(rot), let radius = Double(radius) else {
                result = "Invalid input"
                return
            }
            let speed = (rot * radius) / 0.955
            result = String(format: "%.2f knots", speed)
        }
    }
}

struct ROTView_Previews: PreviewProvider {
    static var previews: some View {
        ROTView().environmentObject(NightMode())
    }
}
