import SwiftUI

struct STDView: View {
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var systemColorScheme

    @State private var time: String = ""
    @State private var distance: String = ""
    @State private var speed: String = ""
    @State private var calculatedValue: String = ""
    @State private var calculationType: CalculationType = .speed

    enum CalculationType: String, CaseIterable, Identifiable {
        case speed = "Speed"
        case time = "Time"
        case distance = "Distance"
        var id: String { self.rawValue }
    }

    var isDark: Bool {
        nightMode.isEnabled || systemColorScheme == .dark
    }

    var body: some View {
        ZStack {
            (isDark ? Color.black : Color("TileBackground"))
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Speed, Time, Distance Calculator")
                        .font(.custom("Avenir", size: 34))
                        .bold()
                        .padding()
                        .foregroundColor(isDark ? .green : .black)

                    Picker("Select Calculation Type", selection: $calculationType) {
                        ForEach(CalculationType.allCases) { type in
                            Text(type.rawValue).tag(type)
                        }
                    }
                    .pickerStyle(SegmentedPickerStyle())
                    .padding()
                    .tint(isDark ? .green : .black)

                    VStack(spacing: 20) {
                        if calculationType == .speed {
                            InputField(label: "Time (hh.hh)", placeholder: "Enter Time", text: $time)
                            InputField(label: "Distance (nm)", placeholder: "Enter Distance", text: $distance)
                        } else if calculationType == .time {
                            InputField(label: "Speed (knots)", placeholder: "Enter Speed", text: $speed)
                            InputField(label: "Distance (nm)", placeholder: "Enter Distance", text: $distance)
                        } else {
                            InputField(label: "Speed (knots)", placeholder: "Enter Speed", text: $speed)
                            InputField(label: "Time (hh.hh)", placeholder: "Enter Time", text: $time)
                        }
                    }

                    Button("Calculate", action: calculate)
                        .buttonStyle(FilledButtonStyle())
                        .padding(.horizontal)

                    if !calculatedValue.isEmpty {
                        Text("\(calculationType.rawValue): \(calculatedValue)")
                            .font(.headline)
                            .foregroundColor(isDark ? .green : .black)
                            .padding()
                    }

                    Spacer()
                }
                .padding()
            }
        }
        .dismissKeyboardOnTap()
    }

    private func calculate() {
        switch calculationType {
        case .speed:
            guard let time = Double(time), let distance = Double(distance), time > 0 else {
                calculatedValue = "Invalid input"
                return
            }
            calculatedValue = String(format: "%.1f knots", distance / time)

        case .time:
            guard let speed = Double(speed), let distance = Double(distance), speed > 0 else {
                calculatedValue = "Invalid input"
                return
            }
            calculatedValue = String(format: "%.2f hours", distance / speed)

        case .distance:
            guard let speed = Double(speed), let time = Double(time) else {
                calculatedValue = "Invalid input"
                return
            }
            calculatedValue = String(format: "%.1f nm", speed * time)
        }
    }
}

struct STDView_Previews: PreviewProvider {
    static var previews: some View {
        STDView().environmentObject(NightMode())
    }
}
