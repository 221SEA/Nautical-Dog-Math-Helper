import SwiftUI

struct TurnView: View {
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var systemColorScheme

    @State private var leg1: String = ""
    @State private var leg2: String = ""
    @State private var radius: String = ""
    @State private var delta: String = ""
    @State private var piForTurn: String = ""

    var isDark: Bool {
        nightMode.isEnabled || systemColorScheme == .dark
    }

    var body: some View {
        ZStack {
            (isDark ? Color.black : Color("TileBackground"))
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Turn Calculator")
                        .font(.custom("Avenir", size: 34))
                        .bold()
                        .padding()
                        .foregroundColor(isDark ? .green : .black)

                    Text("This calculates the distance you need to place your parallel index (PI) line ahead of the ship.")
                        .font(.custom("Avenir", size: 18))
                        .padding()
                        .background(isDark ? Color.white.opacity(0.05) : Color.gray.opacity(0.1))
                        .foregroundColor(isDark ? .green : .black)
                        .cornerRadius(8)

                    VStack(spacing: 20) {
                        InputField(label: "Radius of Turn (nm)", placeholder: "Enter Radius", text: $radius)
                        InputField(label: "Leg 1 of Turn (degrees)", placeholder: "Enter Leg 1", text: $leg1)
                        InputField(label: "Leg 2 of Turn (degrees)", placeholder: "Enter Leg 2", text: $leg2)
                    }

                    Button("Calculate", action: calculate)
                        .buttonStyle(FilledButtonStyle())
                        .padding(.horizontal)

                    VStack(spacing: 20) {
                        if !piForTurn.isEmpty {
                            Text("PI for Turn: \(piForTurn) nm")
                                .font(.headline)
                                .foregroundColor(isDark ? .green : .black)
                        }
                        if !delta.isEmpty {
                            Text("Delta of Course Change: \(delta)°")
                                .font(.headline)
                                .foregroundColor(isDark ? .green : .black)
                        }
                    }
                    .padding()

                    Spacer()
                }
                .padding()
            }
        }
        .dismissKeyboardOnTap()
    }

    private func calculate() {
        guard let leg1 = Double(leg1),
              let leg2 = Double(leg2),
              let radius = Double(radius) else {
            delta = "Invalid input"
            piForTurn = ""
            return
        }

        let crsDelta = abs(leg1 - leg2)
        let inverseCrsDelta = 180 - crsDelta
        let chordLength = 2 * radius
        let chordCalc = chordLength * sin(73.0 / 2.0 * .pi / 180) // fixed angle
        let baseAngle = inverseCrsDelta
        let halfAngle = (180 - baseAngle) / 2
        let ratio = sin(halfAngle * .pi / 180) / sin(baseAngle * .pi / 180)
        let piValue = chordCalc * ratio

        delta = String(format: "%.0f", crsDelta)
        piForTurn = String(format: "%.2f", piValue)
    }
}

struct TurnView_Previews: PreviewProvider {
    static var previews: some View {
        TurnView().environmentObject(NightMode())
    }
}
