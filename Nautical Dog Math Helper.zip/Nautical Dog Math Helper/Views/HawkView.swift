import SwiftUI

struct HawkView: View {
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var systemColorScheme

    @State private var heightOfTide: String = ""
    @State private var blockCoefficient: String = ""
    @State private var transitSpeed: String = ""
    @State private var deepDraft: String = ""
    @State private var waterDepthAtHW: String = ""
    @State private var maxStaticDraft: String = ""
    @State private var squat: String = ""
    @State private var underkeelClearance: String = ""
    @State private var ukcWarning: Bool = false

    var isDark: Bool {
        nightMode.isEnabled || systemColorScheme == .dark
    }

    var body: some View {
        ZStack {
            (isDark ? Color.black : Color("TileBackground"))
                .edgesIgnoringSafeArea(.all)

            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    Text("Hawk Inlet Cut: Squat and UKC Calculator")
                        .font(.custom("Avenir", size: 34))
                        .bold()
                        .padding()
                        .foregroundColor(isDark ? .green : .black)

                    Text("CAUTION: 2023 Least Charted Depth = 7.6m. Shoaling may have occurred since then.")
                        .font(.custom("Avenir", size: 18))
                        .foregroundColor(isDark ? .green : .red)
                        .padding(.bottom)

                    VStack(spacing: 20) {
                        InputField(label: "Height of Tide at HW (meters)", placeholder: "Enter Height of Tide", text: $heightOfTide)
                        InputField(label: "Vessel Block Coefficient (Cb)", placeholder: "Enter Block Coefficient (~0.8)", text: $blockCoefficient)
                        InputField(label: "Estimated Transit Speed (knots)", placeholder: "Enter Transit Speed", text: $transitSpeed)
                        InputField(label: "Vessel Deep Draft (meters)", placeholder: "Enter Deep Draft", text: $deepDraft)
                    }

                    Button("Calculate", action: calculate)
                        .buttonStyle(FilledButtonStyle())
                        .padding(.horizontal)

                    Group {
                        if !waterDepthAtHW.isEmpty {
                            ResultField(
                                label: "Water Depth at HW (meters):",
                                value: waterDepthAtHW,
                                color: isDark ? .green : .black
                            )
                        }

                        if !maxStaticDraft.isEmpty {
                            ResultField(
                                label: "Max Static Draft (meters):",
                                value: maxStaticDraft,
                                color: isDark ? .green : .black
                            )
                        }

                        if !squat.isEmpty {
                            ResultField(
                                label: "Squat (meters):",
                                value: squat,
                                color: isDark ? .green : .black
                            )
                        }

                        if !underkeelClearance.isEmpty {
                            VStack(alignment: .leading, spacing: 10) {
                                HighlightedResultField(
                                    label: "Underkeel Clearance (meters):",
                                    value: underkeelClearance,
                                    isWarning: ukcWarning
                                )

                                if ukcWarning {
                                    Text("Calculated UKC is less than COTP req'd min 1.83m!")
                                        .font(.subheadline)
                                        .foregroundColor(.red)
                                        .bold()
                                }
                            }
                        }
                    }

                    Spacer()
                }
                .padding()
            }
        }
        .dismissKeyboardOnTap()
    }

    private func calculate() {
        guard let tide = Double(heightOfTide),
              let cb = Double(blockCoefficient),
              let speed = Double(transitSpeed),
              let draft = Double(deepDraft) else {
            waterDepthAtHW = "Invalid Input"
            squat = ""
            maxStaticDraft = ""
            underkeelClearance = ""
            return
        }

        let chartedDepth = 7.6
        let depthAtHW = chartedDepth + tide
        waterDepthAtHW = String(format: "%.2f", depthAtHW)

        let calculatedSquat = ((cb * 2) * pow(speed, 2)) / 100
        squat = String(format: "%.2f", calculatedSquat)

        let maxDraft = depthAtHW - calculatedSquat - 1.83
        maxStaticDraft = String(format: "%.2f", maxDraft)

        let ukc = depthAtHW - draft - calculatedSquat
        underkeelClearance = String(format: "%.2f", ukc)
        ukcWarning = ukc < 1.83
    }
}

struct HawkView_Previews: PreviewProvider {
    static var previews: some View {
        HawkView().environmentObject(NightMode())
    }
}
