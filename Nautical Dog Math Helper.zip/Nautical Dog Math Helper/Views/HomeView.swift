import SwiftUI

struct HomeView: View {
    @EnvironmentObject var nightMode: NightMode
    @EnvironmentObject var router: MoreRouter
    @Binding var selectedTab: Int
    @State private var showPrivacyPolicy = false

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                Text("Nautical Dog\nMath's Best Friend")
                    .font(.custom("Avenir-Heavy", size: 36))
                    .padding(.top, 40)
                    .padding(.horizontal)
                    .multilineTextAlignment(.center)
                    .foregroundColor(nightMode.isEnabled ? .green : .black)

                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 16) {
                    Button(action: { selectedTab = 1 }) {
                        HomeIcon(title: "Rate of Turn", iconName: "arrow.triangle.turn.up.right.circle", isSystemSymbol: true)
                    }
                    Button(action: { selectedTab = 2 }) {
                        HomeIcon(title: "Turn Transfer", iconName: "arrow.clockwise.circle", isSystemSymbol: true)
                    }
                    Button(action: { selectedTab = 3 }) {
                        HomeIcon(title: "New RPM", iconName: "speedometer", isSystemSymbol: true)
                    }

                    // These four tiles push to MoreView AND navigate directly to destination
                    Button(action: {
                        selectedTab = 4
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            router.navigate(to: .std)
                        }
                    }) {
                        HomeIcon(title: "DST", iconName: "timer", isSystemSymbol: true)
                    }

                    Button(action: {
                        selectedTab = 4
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            router.navigate(to: .anchor)
                        }
                    }) {
                        HomeIcon(title: "Anchor Swing", iconName: "scope", isSystemSymbol: true)
                    }

                    Button(action: {
                        selectedTab = 4
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            router.navigate(to: .hawk)
                        }
                    }) {
                        HomeIcon(title: "Hawk Inlet", iconName: "ferry.fill", isSystemSymbol: true)
                    }

                    Button(action: {
                        selectedTab = 4
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) {
                            router.navigate(to: .convert)
                        }
                    }) {
                        HomeIcon(title: "Convert", iconName: "arrow.left.arrow.right", isSystemSymbol: true)
                    }
                }
                .padding(.horizontal)
                .padding(.bottom)

                Toggle("Night Mode", isOn: $nightMode.isEnabled)
                    .padding(.horizontal)
                    .foregroundColor(nightMode.isEnabled ? .green : .black)

                Button(action: {
                    showPrivacyPolicy.toggle()
                }) {
                    Text("About")
                        .font(.custom("Avenir", size: 16))
                        .foregroundColor(nightMode.isEnabled ? .green : .black)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .trailing)
                .padding(.trailing, 20)
                .padding(.bottom, 40)
                .alert(isPresented: $showPrivacyPolicy) {
                    Alert(
                        title: Text("Build & Privacy"),
                        message: Text("""
Version 1.1.2

Experimental only! Not to be used for navigation.

Privacy Policy: We do not collect any personal data from users of the Nautical Dog Math Helper app.

We do not share any personal data with third parties. If you have any questions about this privacy policy, please contact us at captjillr+NDapp@gmail.com
"""),
                        dismissButton: .default(Text("OK"))
                    )
                }
            }
        }
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(selectedTab: .constant(0))
            .environmentObject(NightMode())
            .environmentObject(MoreRouter())
    }
}
