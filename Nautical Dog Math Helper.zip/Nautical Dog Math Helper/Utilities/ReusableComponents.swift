import SwiftUI

struct FilledButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.custom("Avenir", size: 20))
            .padding(.vertical, 12)
            .frame(maxWidth: .infinity)
            .background(Color("AccentColor"))
            .foregroundColor(.white)
            .cornerRadius(10)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
            .animation(.easeInOut(duration: 0.2), value: configuration.isPressed)
    }
}

struct InputField: View {
    let label: String
    let placeholder: String
    @Binding var text: String
    @EnvironmentObject var nightMode: NightMode
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        let isDark = nightMode.isEnabled || colorScheme == .dark

        VStack(alignment: .leading) {
            Text(label)
                .font(.subheadline)
                .bold()
                .foregroundColor(isDark ? .green : .black)

            TextField(placeholder, text: $text)
                .keyboardType(.decimalPad)
                .padding(10)
                .background(isDark ? Color.white.opacity(0.1) : Color.white)
                .foregroundColor(isDark ? .green : .black)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(isDark ? Color.green.opacity(0.3) : Color.gray.opacity(0.4), lineWidth: 1)
                )
        }
    }
}

struct ResultField: View {
    let label: String
    let value: String
    let color: Color

    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .bold()
                .foregroundColor(color)

            Spacer()

            Text(value)
                .font(.headline)
                .foregroundColor(color)
        }
        .padding(.vertical, 5)
    }
}

struct HighlightedResultField: View {
    let label: String
    let value: String
    let isWarning: Bool

    var body: some View {
        HStack {
            Text(label)
                .font(.subheadline)
                .bold()
                .foregroundColor(.primary)

            Spacer()

            if isWarning {
                HStack(spacing: 5) {
                    Text("⚠️")
                        .font(.headline)
                    Text(value)
                        .font(.headline)
                        .bold()
                        .foregroundColor(.red)
                }
            } else {
                Text(value)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
        }
        .padding(.vertical, 5)
    }
}
