//
//  NightMode.swift
//  Nautical Dog Math Helper
//
//  Created by Jill Russell on 12/29/24.
//

import SwiftUI

class NightMode: ObservableObject {
    @Published var isEnabled: Bool = false
}
