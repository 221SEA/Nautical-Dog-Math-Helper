import SwiftUI

struct HomeIcon: View {
    var title: String
    var iconName: String
    var isSystemSymbol: Bool = false
    @EnvironmentObject var nightMode: NightMode

    var body: some View {
        VStack(spacing: 8) {
            Group {
                if isSystemSymbol {
                    Image(systemName: iconName)
                        .resizable()
                        .scaledToFit()
                        .frame(width: 44, height: 44)
                        .foregroundColor(nightMode.isEnabled ? .green : .black)
                } else {
                    Image(iconName)
                        .resizable()
                        .renderingMode(.template)
                        .scaledToFit()
                        .frame(width: 44, height: 44)
                        .foregroundColor(nightMode.isEnabled ? .green : .black)
                }
            }
            .shadow(radius: 3)

            Text(title)
                .font(.custom("Avenir", size: 12))
                .fontWeight(.medium)
                .multilineTextAlignment(.center)
                .foregroundColor(nightMode.isEnabled ? .green : .black)
        }
        .padding(10)
        .frame(maxWidth: .infinity)
        .background(
            nightMode.isEnabled ? Color.white.opacity(0.05) : Color.white
        )
        .cornerRadius(14)
        .shadow(color: Color.black.opacity(0.05), radius: 2, x: 0, y: 2)
        .overlay(
            RoundedRectangle(cornerRadius: 14)
                .stroke(nightMode.isEnabled ? Color.green.opacity(0.3) : Color("TileBorder"), lineWidth: 0.5)
        )
    }
}

struct HomeIcon_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            HomeIcon(title: "Convert", iconName: "arrow.left.arrow.right", isSystemSymbol: true)
                .environmentObject(NightMode())
                .previewLayout(.sizeThatFits)
        }
    }
}
